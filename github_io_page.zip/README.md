# Ramesh Radhakrishnan - Personal Page

This is my simple personal site hosted on GitHub Pages:  
👉 [https://yourusername.github.io](https://yourusername.github.io)

### Structure
- `index.html` → main page
- `style.css` → styling
- `README.md` → this file
